
// ** React Imports
import { useState, useEffect, useCallback } from 'react'

// ** MUI Imports
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Divider from '@mui/material/Divider'
import MenuItem from '@mui/material/MenuItem'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import CircularProgress from '@mui/material/CircularProgress'
import Chip from '@mui/material/Chip'
import IconButton from '@mui/material/IconButton'
import Tooltip from '@mui/material/Tooltip'
import Alert from '@mui/material/Alert'
import Switch from '@mui/material/Switch'
import FormControlLabel from '@mui/material/FormControlLabel'
import Accordion from '@mui/material/Accordion'
import AccordionSummary from '@mui/material/AccordionSummary'
import AccordionDetails from '@mui/material/AccordionDetails'
import Drawer from '@mui/material/Drawer'
import Skeleton from '@mui/material/Skeleton'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogContentText from '@mui/material/DialogContentText'
import DialogActions from '@mui/material/DialogActions'
import Menu from '@mui/material/Menu'
import ListItemIcon from '@mui/material/ListItemIcon'
import ListItemText from '@mui/material/ListItemText'
import TablePagination from '@mui/material/TablePagination'
import InputAdornment from '@mui/material/InputAdornment'

// ** Icon Imports
import Icon from 'src/@core/components/icon'

// ** Custom Components
import CustomTextField from 'src/@core/components/mui/text-field'

// ** Third Party
import { useForm, Controller, useFieldArray } from 'react-hook-form'
import toast from 'react-hot-toast'
import { useSelector } from 'react-redux'
import { selectRoleSlug } from 'src/store/auth/authSlice'

// ** API
import axiosRequest from 'src/utils/AxiosInterceptor'

// ─── Constants ────────────────────────────────────────────────────────────────

const EMPLOYMENT_TYPES = ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN']

const STATUS_CONFIG = {
  active:   { color: 'success', icon: 'tabler:circle-check',    label: 'Active'   },
  inactive: { color: 'warning', icon: 'tabler:circle-pause',    label: 'Inactive' },
  draft:    { color: 'default', icon: 'tabler:file-description', label: 'Draft'    },
  archived: { color: 'error',   icon: 'tabler:archive',          label: 'Archived' }
}

// ─── Default values aligned with backend model/validation ────────────────────

const defaultPolicyLeaveEntry = {
  leaveTypeId: '',
  name: '',
  code: '',
  color: '#10B981',         // ✅ backend uses 'color', not 'colorCode'
  isPaid: true,
  isActive: true,
  isPublic: true,
  genderRestriction: 'ALL', // ✅ string only, not object
  applicableEmploymentTypes: ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN'],
  minTenureMonths: 0,
  cooldownDays: 0,
  credit: {
    totalPerYear: 0,
    frequency: 'MONTHLY',
    perCycle: 0,
    accrualType: 'YEARLY'
  },
  balance: {
    maxBalance: 0,
    allowNegative: false,
    maxNegative: 0
  },
  carryForward: {
    allowed: false,
    max: 0,
    expiryDays: 0
  },
  encashment: {
    allowed: false,
    maxDays: 0
  },
  application: {
    minDays: 0.5,
    maxDays: null,
    advanceNoticeDays: 0,
    allowBackdated: false,
    allowHalfDay: true
  },
  documentRule: {
    required: false,
    afterDays: 0
  },
  sandwichRule: {
    override: false,
    enabled: false,
    includeHolidays: true,
    includeWeekends: true
  }
}

const defaultPolicyValues = {
  name: '',
  description: '',
  effectiveFrom: '',
  effectiveTo: null,
  status: 'active',
  applicableFor: {
    departments: [],
    roles: [],
    locations: [],
    employmentTypes: ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN']
  },
  sandwichRule: {
    enabled: false,
    includeHolidays: true,
    includeWeekends: true,
    consecutiveLeaveThreshold: 2
  },
  leaveTypes: []
}

// ─── Confirm Dialog ───────────────────────────────────────────────────────────

const ConfirmDialog = ({
  open, onClose, onConfirm, title, message,
  confirmLabel = 'Confirm', confirmColor = 'primary', loading = false
}) => (
  <Dialog open={open} onClose={onClose} maxWidth='xs' fullWidth>
    <DialogTitle>{title}</DialogTitle>
    <DialogContent>
      <DialogContentText>{message}</DialogContentText>
    </DialogContent>
    <DialogActions sx={{ px: 3, pb: 3 }}>
      <Button variant='tonal' color='secondary' onClick={onClose} disabled={loading}>Cancel</Button>
      <Button variant='contained' color={confirmColor} onClick={onConfirm} disabled={loading}
        startIcon={loading ? <CircularProgress size={16} color='inherit' /> : null}
      >
        {loading ? 'Please wait...' : confirmLabel}
      </Button>
    </DialogActions>
  </Dialog>
)

// ─── Master Leave Types Hook ──────────────────────────────────────────────────

const useMasterLeaveTypes = () => {
  const [leaveTypes, setLeaveTypes] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTypes = async () => {
      try {
        const res = await axiosRequest.get('/api/v1/leave/types')
        if (res?.success) setLeaveTypes(res.data ?? [])
      } catch {
        toast.error('Failed to load leave types')
      } finally {
        setLoading(false)
      }
    }
    fetchTypes()
  }, [])

  return { leaveTypes, loading }
}

// ─── LeaveTypesSection ────────────────────────────────────────────────────────

const LeaveTypesSection = ({ control, watch, setValue, masterLeaveTypes, masterLoading }) => {
  const { fields, append, remove } = useFieldArray({ control, name: 'leaveTypes' })
  const [expanded, setExpanded] = useState(null)

  // ✅ Map master leave type fields to backend-aligned form fields
  const handleLeaveTypeSelect = (index, leaveTypeId) => {
    const master = masterLeaveTypes.find(lt => lt._id === leaveTypeId)
    if (!master) return
    const prefix = `leaveTypes.${index}`

    setValue(`${prefix}.name`, master.name)
    setValue(`${prefix}.code`, master.code)
    setValue(`${prefix}.color`, master.colorCode || master.color || '#10B981') // ✅ map to 'color'
    setValue(`${prefix}.isPaid`, master.isPaid ?? true)
    setValue(`${prefix}.isActive`, master.isActive ?? true)
    setValue(`${prefix}.genderRestriction`, master.applicableGender ?? 'ALL') // ✅ string only
    setValue(`${prefix}.applicableEmploymentTypes`, master.applicableEmploymentTypes ?? ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN'])

    // credit — map master flat fields to nested credit object
    setValue(`${prefix}.credit.totalPerYear`, master.defaultDaysPerYear ?? 0)
    setValue(`${prefix}.credit.perCycle`, master.accrualRatePerMonth ?? 0)
    setValue(`${prefix}.credit.frequency`, master.credit?.frequency ?? 'MONTHLY')
    setValue(`${prefix}.credit.accrualType`, master.credit?.accrualType ?? 'YEARLY')

    // carryForward
    setValue(`${prefix}.carryForward.allowed`, master.isCarryForwardAllowed ?? false)
    setValue(`${prefix}.carryForward.max`, master.carryForwardLimit ?? 0)

    // encashment
    setValue(`${prefix}.encashment.allowed`, master.isEncashmentAllowed ?? false)

    // application
    setValue(`${prefix}.application.allowHalfDay`, master.isHalfDayAllowed ?? true)
    setValue(`${prefix}.application.advanceNoticeDays`, master.minNoticeDays ?? 0)

    // documentRule
    setValue(`${prefix}.documentRule.required`, master.requiresDocumentAfterDays != null)
    setValue(`${prefix}.documentRule.afterDays`, master.requiresDocumentAfterDays ?? 0)

    // sandwichRule
    setValue(`${prefix}.sandwichRule.enabled`, master.isSandwichApplicable ?? false)
  }

  const addLeaveType = () => {
    append({ ...defaultPolicyLeaveEntry })
    setExpanded(fields.length)
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant='subtitle1' fontWeight={600}>Leave Types in Policy</Typography>
          <Typography variant='caption' color='text.secondary'>
            Select from master leave types and override policy-level settings
          </Typography>
        </Box>
        <Button size='small' variant='tonal' startIcon={<Icon icon='tabler:plus' />} onClick={addLeaveType}>
          Add Leave Type
        </Button>
      </Box>

      {fields.length === 0 && (
        <Alert severity='info' sx={{ mb: 3 }}>
          No leave types added. Click "Add Leave Type" to include types from the master list.
        </Alert>
      )}

      {fields.map((field, index) => {
        const p = `leaveTypes.${index}`
        const cfAllowed  = watch(`${p}.carryForward.allowed`)
        const encAllowed = watch(`${p}.encashment.allowed`)
        const docReq     = watch(`${p}.documentRule.required`)
        const colorVal   = watch(`${p}.color`)   // ✅ 'color' not 'colorCode'
        const nameVal    = watch(`${p}.name`)
        const codeVal    = watch(`${p}.code`)
        const leaveTypeId = watch(`${p}.leaveTypeId`)

        return (
          <Accordion
            key={field.id}
            expanded={expanded === index}
            onChange={() => setExpanded(expanded === index ? null : index)}
            sx={{
              mb: 2,
              '&:before': { display: 'none' },
              border: t => `1px solid ${t.palette.divider}`,
              borderLeft: `4px solid ${colorVal || '#6B7280'}`,
              borderRadius: '8px !important',
              boxShadow: 'none'
            }}
          >
            <AccordionSummary expandIcon={<Icon icon='tabler:chevron-down' />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                <Box sx={{
                  width: 32, height: 32, borderRadius: 1,
                  backgroundColor: colorVal || '#6B7280',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
                }}>
                  <Typography variant='caption' fontWeight={700} color='white' sx={{ fontSize: '0.65rem' }}>
                    {codeVal || '?'}
                  </Typography>
                </Box>
                <Typography fontWeight={500}>{nameVal || 'Select a leave type...'}</Typography>
                {!leaveTypeId && <Chip label='Not configured' size='small' color='warning' variant='tonal' />}
                <Box sx={{ ml: 'auto', mr: 1 }}>
                  <Button size='small' color='error' variant='tonal'
                    onClick={e => { e.stopPropagation(); remove(index) }}
                    startIcon={<Icon icon='tabler:trash' fontSize='1rem' />}
                  >
                    Remove
                  </Button>
                </Box>
              </Box>
            </AccordionSummary>

            <AccordionDetails>
              <Grid container spacing={4}>

                {/* Select master leave type */}
                <Grid item xs={12}>
                  <Typography variant='overline' color='text.secondary' sx={{ display: 'block', mb: 2 }}>
                    Select Leave Type
                  </Typography>
                  {masterLoading ? (
                    <Skeleton variant='rectangular' height={56} sx={{ borderRadius: 1 }} />
                  ) : (
                    <Controller
                      name={`${p}.leaveTypeId`}
                      control={control}
                      rules={{ required: 'Please select a leave type' }}
                      render={({ field, fieldState }) => (
                        <CustomTextField
                          select fullWidth label='Master Leave Type *'
                          value={field.value || ''}
                          onChange={e => { field.onChange(e.target.value); handleLeaveTypeSelect(index, e.target.value) }}
                          error={!!fieldState.error}
                          helperText={fieldState.error?.message ?? 'All fields below will auto-fill and can be overridden'}
                        >
                          {masterLeaveTypes.map(lt => (
                            <MenuItem key={lt._id} value={lt._id}>
                              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: lt.colorCode || lt.color || '#6B7280', flexShrink: 0 }} />
                                <span>{lt.name}</span>
                                <Typography variant='caption' color='text.secondary' sx={{ ml: 0.5 }}>
                                  ({lt.code}) · {lt.defaultDaysPerYear} days/yr
                                </Typography>
                              </Box>
                            </MenuItem>
                          ))}
                        </CustomTextField>
                      )}
                    />
                  )}
                </Grid>

                {leaveTypeId && (
                  <>
                    <Grid item xs={12}>
                      <Divider textAlign='left'>
                        <Typography variant='caption' color='text.secondary'>Policy-Level Overrides</Typography>
                      </Divider>
                    </Grid>

                    {/* Basic Info */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Basic Info</Typography>
                    </Grid>
                    <Grid item xs={12} sm={5}>
                      <Controller name={`${p}.name`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth label='Display Name' />}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.code`} control={control}
                        render={({ field }) => (
                          <CustomTextField {...field} fullWidth label='Code'
                            onChange={e => field.onChange(e.target.value.toUpperCase())}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6} sm={4} sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                      <Controller name={`${p}.isPaid`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Paid'
                          />
                        )}
                      />
                      <Controller name={`${p}.isActive`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Active'
                          />
                        )}
                      />
                    </Grid>

                    {/* Color — ✅ field name is 'color' */}
                    <Grid item xs={12}>
                      <Typography variant='body2' color='text.secondary' sx={{ mb: 1.5 }}>Color</Typography>
                      <Controller name={`${p}.color`} control={control}
                        render={({ field }) => (
                          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
                            {['#10B981', '#4F46E5', '#F59E0B', '#EF4444', '#3B82F6', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316', '#6B7280'].map(c => (
                              <Box key={c} onClick={() => field.onChange(c)}
                                sx={{
                                  width: 22, height: 22, borderRadius: '50%', backgroundColor: c, cursor: 'pointer',
                                  border: field.value === c ? '3px solid white' : '2px solid transparent',
                                  outline: field.value === c ? `2px solid ${c}` : 'none',
                                  transition: 'transform 0.15s',
                                  '&:hover': { transform: 'scale(1.2)' }
                                }}
                              />
                            ))}
                            <input type='color' value={field.value || '#10B981'}
                              onChange={e => field.onChange(e.target.value)}
                              style={{ width: 22, height: 22, border: 'none', borderRadius: '50%', cursor: 'pointer', padding: 0 }}
                            />
                          </Box>
                        )}
                      />
                    </Grid>

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Credit & Accrual */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Credit & Accrual</Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.credit.totalPerYear`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Days / Year' />}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.credit.perCycle`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Per Cycle' />}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.credit.frequency`} control={control}
                        render={({ field }) => (
                          <CustomTextField {...field} select fullWidth label='Frequency'>
                            <MenuItem value='MONTHLY'>Monthly</MenuItem>
                            <MenuItem value='QUARTERLY'>Quarterly</MenuItem>
                            <MenuItem value='YEARLY'>Yearly</MenuItem>
                            <MenuItem value='NONE'>None</MenuItem>
                          </CustomTextField>
                        )}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.credit.accrualType`} control={control}
                        render={({ field }) => (
                          <CustomTextField {...field} select fullWidth label='Accrual Type'>
                            <MenuItem value='MONTHLY'>Monthly</MenuItem>
                            <MenuItem value='QUARTERLY'>Quarterly</MenuItem>
                            <MenuItem value='YEARLY'>Yearly</MenuItem>
                            <MenuItem value='NONE'>None</MenuItem>
                          </CustomTextField>
                        )}
                      />
                    </Grid>

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Balance */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Balance</Typography>
                    </Grid>
                    <Grid item xs={6} sm={4}>
                      <Controller name={`${p}.balance.maxBalance`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Max Balance (days)' />}
                      />
                    </Grid>
                    <Grid item xs={6} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
                      <Controller name={`${p}.balance.allowNegative`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Allow Negative'
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6} sm={4}>
                      <Controller name={`${p}.balance.maxNegative`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Max Negative Days' />}
                      />
                    </Grid>

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Carry Forward — ✅ directly using carryForward.allowed */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Carry Forward</Typography>
                    </Grid>
                    <Grid item xs={12} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
                      <Controller name={`${p}.carryForward.allowed`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Allow Carry Forward'
                          />
                        )}
                      />
                    </Grid>
                    {cfAllowed && (
                      <>
                        <Grid item xs={6} sm={4}>
                          {/* ✅ directly carryForward.max */}
                          <Controller name={`${p}.carryForward.max`} control={control}
                            render={({ field }) => (
                              <CustomTextField {...field} fullWidth type='number' label='CF Limit (days)' />
                            )}
                          />
                        </Grid>
                        <Grid item xs={6} sm={4}>
                          <Controller name={`${p}.carryForward.expiryDays`} control={control}
                            render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Expiry (days)' />}
                          />
                        </Grid>
                      </>
                    )}

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Encashment — ✅ directly using encashment.allowed */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Encashment</Typography>
                    </Grid>
                    <Grid item xs={12} sm={6} sx={{ display: 'flex', alignItems: 'center' }}>
                      <Controller name={`${p}.encashment.allowed`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Allow Encashment'
                          />
                        )}
                      />
                    </Grid>
                    {encAllowed && (
                      <Grid item xs={12} sm={6}>
                        <Controller name={`${p}.encashment.maxDays`} control={control}
                          render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Max Encashment Days' />}
                        />
                      </Grid>
                    )}

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Application Rules — ✅ all nested under application.* */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Application Rules</Typography>
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.application.minDays`} control={control}
                        render={({ field }) => <CustomTextField {...field} fullWidth type='number' label='Min Days' />}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.application.maxDays`} control={control}
                        render={({ field }) => (
                          <CustomTextField fullWidth type='number' label='Max Days' placeholder='No limit'
                            value={field.value ?? ''}
                            onChange={e => field.onChange(e.target.value === '' ? null : Number(e.target.value))}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      {/* ✅ directly application.advanceNoticeDays */}
                      <Controller name={`${p}.application.advanceNoticeDays`} control={control}
                        render={({ field }) => (
                          <CustomTextField {...field} fullWidth type='number' label='Min Notice Days' />
                        )}
                      />
                    </Grid>
                    <Grid item xs={6} sm={3}>
                      <Controller name={`${p}.application.maxPerMonth`} control={control}
                        render={({ field }) => (
                          <CustomTextField fullWidth type='number' label='Max Per Month' placeholder='No limit'
                            value={field.value ?? ''}
                            onChange={e => field.onChange(e.target.value === '' ? null : Number(e.target.value))}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                      {/* ✅ directly application.allowHalfDay */}
                      <Controller name={`${p}.application.allowHalfDay`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Allow Half Day'
                          />
                        )}
                      />
                      <Controller name={`${p}.application.allowBackdated`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Allow Backdated'
                          />
                        )}
                      />
                      {/* ✅ directly sandwichRule.enabled */}
                      <Controller name={`${p}.sandwichRule.enabled`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Sandwich Rule'
                          />
                        )}
                      />
                    </Grid>

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Document Rule */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Document Rule</Typography>
                    </Grid>
                    <Grid item xs={12} sm={6} sx={{ display: 'flex', alignItems: 'center' }}>
                      <Controller name={`${p}.documentRule.required`} control={control}
                        render={({ field }) => (
                          <FormControlLabel
                            control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                            label='Document Required'
                          />
                        )}
                      />
                    </Grid>
                    {docReq && (
                      <Grid item xs={12} sm={6}>
                        {/* ✅ directly documentRule.afterDays */}
                        <Controller name={`${p}.documentRule.afterDays`} control={control}
                          render={({ field }) => (
                            <CustomTextField fullWidth type='number' label='Required After (days)'
                              value={field.value ?? ''}
                              onChange={e => field.onChange(e.target.value === '' ? null : Number(e.target.value))}
                            />
                          )}
                        />
                      </Grid>
                    )}

                    <Grid item xs={12}><Divider /></Grid>

                    {/* Applicability */}
                    <Grid item xs={12}>
                      <Typography variant='overline' color='text.secondary'>Applicability</Typography>
                    </Grid>
                    {/* ✅ Single genderRestriction field (string), duplicate applicableGender removed */}
                    <Grid item xs={12} sm={6}>
                      <Controller name={`${p}.genderRestriction`} control={control}
                        render={({ field }) => (
                          <CustomTextField {...field} select fullWidth label='Applicable Gender'>
                            <MenuItem value='ALL'>All</MenuItem>
                            <MenuItem value='MALE'>Male</MenuItem>
                            <MenuItem value='FEMALE'>Female</MenuItem>
                            <MenuItem value='OTHER'>Other</MenuItem>
                          </CustomTextField>
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Typography variant='body2' color='text.secondary' sx={{ mb: 1 }}>Employment Types</Typography>
                      <Controller name={`${p}.applicableEmploymentTypes`} control={control}
                        render={({ field }) => (
                          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                            {['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN'].map(type => {
                              const checked = field.value?.includes(type)
                              return (
                                <Chip key={type} label={type.replace('_', ' ')} clickable size='small'
                                  color={checked ? 'primary' : 'default'}
                                  variant={checked ? 'filled' : 'outlined'}
                                  onClick={() => {
                                    const cur = field.value || []
                                    field.onChange(checked ? cur.filter(t => t !== type) : [...cur, type])
                                  }}
                                />
                              )
                            })}
                          </Box>
                        )}
                      />
                    </Grid>
                  </>
                )}
              </Grid>
            </AccordionDetails>
          </Accordion>
        )
      })}
    </Box>
  )
}

// ─── Policy Drawer ────────────────────────────────────────────────────────────

const LeavePolicyDrawer = ({ open, onClose, editData, onSuccess }) => {
  const [saving, setSaving] = useState(false)
  const isEdit = Boolean(editData?._id)
  const { leaveTypes: masterLeaveTypes, loading: masterLoading } = useMasterLeaveTypes()

  const { control, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm({
    defaultValues: defaultPolicyValues
  })

  useEffect(() => {
    if (open) {
      if (editData) {
        reset({
          ...defaultPolicyValues,
          ...editData,
          leaveTypes: (editData.leaveTypes || []).map(lt => ({
            ...defaultPolicyLeaveEntry,
            leaveTypeId: lt.leaveTypeId || '',
            name: lt.name || '',
            code: lt.code || '',
            color: lt.color || '#10B981',                    // ✅ 'color' not 'colorCode'
            isPaid: lt.isPaid ?? true,
            isActive: lt.isActive ?? true,
            isPublic: lt.isPublic ?? true,
            genderRestriction: lt.genderRestriction ?? 'ALL', // ✅ string only
            applicableEmploymentTypes: lt.applicableEmploymentTypes ?? ['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN'],
            minTenureMonths: lt.minTenureMonths ?? 0,
            cooldownDays: lt.cooldownDays ?? 0,
            credit: lt.credit ?? defaultPolicyLeaveEntry.credit,
            balance: lt.balance ?? defaultPolicyLeaveEntry.balance,
            carryForward: lt.carryForward ?? defaultPolicyLeaveEntry.carryForward,
            encashment: lt.encashment ?? defaultPolicyLeaveEntry.encashment,
            application: lt.application ?? defaultPolicyLeaveEntry.application,
            documentRule: lt.documentRule ?? defaultPolicyLeaveEntry.documentRule,
            sandwichRule: lt.sandwichRule ?? defaultPolicyLeaveEntry.sandwichRule,
          }))
        })
      } else {
        reset(defaultPolicyValues)
      }
    }
  }, [open, editData])

  // ✅ Strip internal/meta fields before sending to backend
  const stripIds = (value) => {
    if (Array.isArray(value)) return value.map(stripIds)
    if (value && typeof value === 'object') {
     const keysToRemove = new Set([
'_id', 'id', 'tenantId', 'createdAt', 'updatedAt',
'createdBy', 'updatedBy', 'archivedAt', 'archivedBy',
'activatedAt', 'activatedBy', '__v', 'version'
// isActive yahan nahi — leaveType ke andar chahiye
])
      return Object.entries(value).reduce((acc, [key, val]) => {
        if (keysToRemove.has(key)) return acc
        acc[key] = stripIds(val)
        return acc
      }, {})
    }
    return value
  }

 const onSubmit = async (data) => {
  const { leaveTypes, ...metaData } = data

  // Remove top-level virtual/internal fields
  delete metaData.isActive
  delete metaData.totalLeaveTypesCount
  delete metaData.activeLeaveTypes

  const cleanMeta = stripIds(metaData)
  const cleanLeaveTypes = stripIds(leaveTypes)

  setSaving(true)
  try {
    const url = isEdit
      ? `/api/v1/leave-policies/${editData._id}`
      : `/api/v1/leave-policies`

    // Step 1 — Create or update policy meta
    const metaRes = isEdit
      ? await axiosRequest.put(url, cleanMeta)
      : await axiosRequest.post(url, cleanMeta)

    if (!metaRes?.success) return

    const policyId = isEdit ? editData._id : metaRes.data?._id

    // Step 2 — Update leave types (only if any added)
    if (cleanLeaveTypes?.length > 0) {
      await axiosRequest.put(
        `/api/v1/leave-policies/${policyId}/leave-types`,
        { leaveTypes: cleanLeaveTypes }
      )
    }

    toast.success(`Policy ${isEdit ? 'updated' : 'created'} successfully`)
    onSuccess(metaRes.data, isEdit)
    onClose()

  } catch (err) {
    toast.error(err?.response?.data?.message || 'Failed to save policy')
  } finally {
    setSaving(false)
  }
}

  return (
    <Drawer open={open} anchor='right' onClose={onClose}
      PaperProps={{ sx: { width: { xs: '100%', sm: 760 } } }}
    >
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 5, py: 4, borderBottom: t => `1px solid ${t.palette.divider}`
      }}>
        <Box>
          <Typography variant='h6'>{isEdit ? 'Edit Leave Policy' : 'New Leave Policy'}</Typography>
          <Typography variant='caption' color='text.secondary'>
            Group leave types and define policy-level overrides
          </Typography>
        </Box>
        <IconButton onClick={onClose} size='small'><Icon icon='tabler:x' /></IconButton>
      </Box>

      <Box component='form' onSubmit={handleSubmit(onSubmit)}
        sx={{ px: 5, py: 4, overflow: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}
      >
        {/* Policy Meta */}
        <Box>
          <Typography variant='overline' color='text.secondary' sx={{ display: 'block', mb: 3 }}>
            Policy Details
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12} sm={8}>
              <Controller name='name' control={control} rules={{ required: 'Policy name required' }}
                render={({ field }) => (
                  <CustomTextField {...field} fullWidth label='Policy Name *'
                    error={!!errors.name} helperText={errors.name?.message}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <Controller name='status' control={control}
                render={({ field }) => (
                  <CustomTextField {...field} select fullWidth label='Status'>
                    <MenuItem value='active'>Active</MenuItem>
                    <MenuItem value='draft'>Draft</MenuItem>
                  </CustomTextField>
                )}
              />
            </Grid>
            <Grid item xs={12}>
              <Controller name='description' control={control}
                render={({ field }) => (
                  <CustomTextField {...field} fullWidth multiline rows={2} label='Description' />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Controller name='effectiveFrom' control={control}
                render={({ field }) => (
                  <CustomTextField {...field} fullWidth type='date' label='Effective From'
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Controller name='effectiveTo' control={control}
                render={({ field }) => (
                  <CustomTextField
                    fullWidth type='date' label='Effective To (optional)'
                    InputLabelProps={{ shrink: true }}
                    value={field.value ?? ''}
                    onChange={e => field.onChange(e.target.value || null)}
                  />
                )}
              />
            </Grid>
          </Grid>
        </Box>

        <Divider />

        {/* Applicability */}
        <Box>
          <Typography variant='overline' color='text.secondary' sx={{ display: 'block', mb: 3 }}>
            Applicability
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12}>
              <Typography variant='body2' color='text.secondary' sx={{ mb: 1.5 }}>Employment Types</Typography>
              <Controller name='applicableFor.employmentTypes' control={control}
                render={({ field }) => (
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                    {EMPLOYMENT_TYPES.map(type => {
                      const checked = field.value?.includes(type)
                      return (
                        <Chip key={type} label={type} clickable size='small'
                          color={checked ? 'primary' : 'default'}
                          variant={checked ? 'filled' : 'outlined'}
                          onClick={() => {
                            const cur = field.value || []
                            field.onChange(checked ? cur.filter(t => t !== type) : [...cur, type])
                          }}
                        />
                      )
                    })}
                  </Box>
                )}
              />
            </Grid>
          </Grid>
        </Box>

        <Divider />

        {/* Sandwich Rule */}
        <Box>
          <Typography variant='overline' color='text.secondary' sx={{ display: 'block', mb: 3 }}>
            Sandwich Rule
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
              <Controller name='sandwichRule.enabled' control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                    label='Enable Sandwich Rule'
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
              <Controller name='sandwichRule.includeHolidays' control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                    label='Include Holidays'
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={4} sx={{ display: 'flex', alignItems: 'center' }}>
              <Controller name='sandwichRule.includeWeekends' control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={<Switch checked={field.value} onChange={e => field.onChange(e.target.checked)} />}
                    label='Include Weekends'
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <Controller name='sandwichRule.consecutiveLeaveThreshold' control={control}
                render={({ field }) => (
                  <CustomTextField {...field} fullWidth type='number' label='Consecutive Threshold (days)' />
                )}
              />
            </Grid>
          </Grid>
        </Box>

        <Divider />

        {/* Leave Types */}
        <LeaveTypesSection
          control={control}
          watch={watch}
          setValue={setValue}
          masterLeaveTypes={masterLeaveTypes}
          masterLoading={masterLoading}
        />

        {/* Footer */}
        <Box sx={{ mt: 'auto', pt: 4, display: 'flex', gap: 3, justifyContent: 'flex-end' }}>
          <Button variant='tonal' color='secondary' onClick={onClose} disabled={saving}>Cancel</Button>
          <Button type='submit' variant='contained' disabled={saving}
            startIcon={saving ? <CircularProgress size={16} color='inherit' /> : null}
          >
            {saving ? 'Saving...' : isEdit ? 'Update Policy' : 'Create Policy'}
          </Button>
        </Box>
      </Box>
    </Drawer>
  )
}

// ─── Policy Card Actions Menu ─────────────────────────────────────────────────

const PolicyActionsMenu = ({ policy, onEdit, onActivate, onDeactivate, onArchive, onDelete, actionLoading }) => {
  const [anchorEl, setAnchorEl] = useState(null)
  const open = Boolean(anchorEl)
  const status = policy.status

  const close = () => setAnchorEl(null)
  const handle = (fn) => () => { close(); fn(policy) }
  const isLoading = actionLoading === policy._id

  return (
    <>
      <IconButton size='small' onClick={e => setAnchorEl(e.currentTarget)} disabled={isLoading}>
        {isLoading
          ? <CircularProgress size={16} />
          : <Icon icon='tabler:dots-vertical' fontSize='1.1rem' />
        }
      </IconButton>
      <Menu anchorEl={anchorEl} open={open} onClose={close}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        {status !== 'archived' && (
          <MenuItem onClick={handle(onEdit)}>
            <ListItemIcon><Icon icon='tabler:pencil' fontSize='1rem' /></ListItemIcon>
            <ListItemText>Edit Policy</ListItemText>
          </MenuItem>
        )}
        {(status === 'draft' || status === 'inactive') && onActivate && (
          <MenuItem onClick={handle(onActivate)}>
            <ListItemIcon><Icon icon='tabler:circle-check' fontSize='1rem' color='#10B981' /></ListItemIcon>
            <ListItemText>Activate</ListItemText>
          </MenuItem>
        )}
        {status === 'active' && onDeactivate && (
          <MenuItem onClick={handle(onDeactivate)}>
            <ListItemIcon><Icon icon='tabler:circle-pause' fontSize='1rem' color='#F59E0B' /></ListItemIcon>
            <ListItemText>Deactivate</ListItemText>
          </MenuItem>
        )}
        {(status === 'active' || status === 'inactive') && onArchive && (
          <MenuItem onClick={handle(onArchive)}>
            <ListItemIcon><Icon icon='tabler:archive' fontSize='1rem' color='#6B7280' /></ListItemIcon>
            <ListItemText>Archive</ListItemText>
          </MenuItem>
        )}
        {(status === 'draft' || status === 'inactive' || status === 'archived') && (
          <MenuItem onClick={handle(onDelete)} sx={{ color: 'error.main' }}>
            <ListItemIcon><Icon icon='tabler:trash' fontSize='1rem' color='inherit' style={{ color: 'var(--mui-palette-error-main)' }} /></ListItemIcon>
            <ListItemText>Delete</ListItemText>
          </MenuItem>
        )}
      </Menu>
    </>
  )
}

// ─── TabLeavePolicy ───────────────────────────────────────────────────────────

const TabLeavePolicy = () => {
  const roleSlug   = useSelector(selectRoleSlug)
  const canActivate = roleSlug === 'unit_admin'
  const [policies, setPolicies] = useState([])
  const [loading, setLoading] = useState(true)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [editData, setEditData] = useState(null)
  const [actionLoading, setActionLoading] = useState(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [pagination, setPagination] = useState({ total: 0, pages: 1 })

  const [confirm, setConfirm] = useState({
    open: false, title: '', message: '', action: null, color: 'primary', label: ''
  })

  const fetchPolicies = useCallback(async (overridePage) => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.set('status', statusFilter)
      if (search) params.set('search', search)
      params.set('page', (overridePage ?? page) + 1)
      params.set('limit', rowsPerPage)

      const res = await axiosRequest.get(`/api/v1/leave-policies?${params.toString()}`)
      if (res?.success) {
        setPolicies(res.data?.policies ?? [])
        setPagination(res.data?.pagination ?? { total: 0, pages: 1 })
      }
    } catch {
      toast.error('Failed to load leave policies')
    } finally {
      setLoading(false)
    }
  }, [statusFilter, search, page, rowsPerPage])

  useEffect(() => { fetchPolicies() }, [fetchPolicies])

  const handleSuccess = (record, isEdit) => {
    const policy = record?.policies?.[0] ?? record
    if (isEdit) {
      setPolicies(prev => prev.map(p => p._id === policy._id ? policy : p))
    } else {
      fetchPolicies()
    }
  }

  const doAction = async (policy, method, urlSuffix, successMsg, updateFn) => {
    setActionLoading(policy._id)
    try {
      const res = method === 'delete'
        ? await axiosRequest.delete(`/api/v1/leave-policies/${policy._id}${urlSuffix}`)
        : await axiosRequest[method](`/api/v1/leave-policies/${policy._id}${urlSuffix}`)

      if (res?.success) {
        toast.success(successMsg)
        if (updateFn) updateFn(res.data)
        else fetchPolicies()
      }
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Action failed')
    } finally {
      setActionLoading(null)
    }
  }

  const openConfirm = (title, message, action, color = 'primary', label = 'Confirm') => {
    setConfirm({ open: true, title, message, action, color, label })
  }

  const handleActivate = (policy) => openConfirm(
    'Activate Policy',
    `Activate "${policy.name}"? It will become the active policy for matched employees.`,
    () => doAction(policy, 'patch', '/activate', 'Policy activated', updated => {
      const p = updated?.policies?.[0] ?? updated
      setPolicies(prev => prev.map(x => x._id === p._id ? p : x))
    }),
    'success', 'Activate'
  )

  const handleDeactivate = (policy) => openConfirm(
    'Deactivate Policy',
    `Deactivate "${policy.name}"? Employees won't be able to apply for new leaves under this policy.`,
    () => doAction(policy, 'patch', '/deactivate', 'Policy deactivated', updated => {
      const p = updated?.policies?.[0] ?? updated
      setPolicies(prev => prev.map(x => x._id === p._id ? p : x))
    }),
    'warning', 'Deactivate'
  )

  const handleArchive = (policy) => openConfirm(
    'Archive Policy',
    `Archive "${policy.name}"? It will be read-only and can no longer be activated.`,
    () => doAction(policy, 'patch', '/archive', 'Policy archived', updated => {
      const p = updated?.policies?.[0] ?? updated
      setPolicies(prev => prev.map(x => x._id === p._id ? p : x))
    }),
    'default', 'Archive'
  )

  const handleDelete = (policy) => openConfirm(
    'Delete Policy',
    `Permanently delete "${policy.name}"? This cannot be undone.`,
    () => doAction(policy, 'delete', '', 'Policy deleted', () => {
      setPolicies(prev => prev.filter(p => p._id !== policy._id))
    }),
    'error', 'Delete'
  )

  const handleEdit = (policy) => {
    setEditData(policy)
    setDrawerOpen(true)
  }

  const execConfirm = async () => {
    if (confirm.action) await confirm.action()
    setConfirm(c => ({ ...c, open: false }))
  }

  const formatDate = (d) => d
    ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : '—'

  const StatusChip = ({ status }) => {
    const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.draft
    return (
      <Chip
        icon={<Icon icon={cfg.icon} fontSize='0.75rem' />}
        label={cfg.label}
        size='small'
        color={cfg.color}
        variant='tonal'
        sx={{ '& .MuiChip-icon': { ml: 1 } }}
      />
    )
  }

  return (
    <Card>
      <CardHeader
        title='Leave Policies'
        subheader='Group master leave types into policies and override settings per policy'
        action={
          <Button variant='contained' startIcon={<Icon icon='tabler:plus' />}
            onClick={() => { setEditData(null); setDrawerOpen(true) }}
          >
            New Policy
          </Button>
        }
      />
      <Divider />

      {/* Filters */}
      <Box sx={{ px: 5, py: 3, display: 'flex', gap: 3, flexWrap: 'wrap', alignItems: 'center' }}>
        <CustomTextField
          size='small'
          placeholder='Search policies...'
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(0) }}
          sx={{ minWidth: 220 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position='start'>
                <Icon icon='tabler:search' fontSize='1rem' />
              </InputAdornment>
            )
          }}
        />
        <CustomTextField
          select size='small' label='Status' value={statusFilter}
          onChange={e => { setStatusFilter(e.target.value); setPage(0) }}
          sx={{ minWidth: 140 }}
        >
          <MenuItem value='all'>All Statuses</MenuItem>
          <MenuItem value='active'>Active</MenuItem>
          <MenuItem value='inactive'>Inactive</MenuItem>
          <MenuItem value='draft'>Draft</MenuItem>
          <MenuItem value='archived'>Archived</MenuItem>
        </CustomTextField>
        <Typography variant='caption' color='text.secondary' sx={{ ml: 'auto' }}>
          {pagination.total} polic{pagination.total !== 1 ? 'ies' : 'y'}
        </Typography>
      </Box>

      <Divider />

      <CardContent sx={{ p: 0 }}>
        {loading ? (
          <Box sx={{ p: 5, display: 'flex', flexDirection: 'column', gap: 3 }}>
            {[1, 2, 3].map(i => <Skeleton key={i} variant='rectangular' height={110} sx={{ borderRadius: 2 }} />)}
          </Box>
        ) : policies.length === 0 ? (
          <Box sx={{ p: 5 }}>
            <Alert severity='info'>
              {search || statusFilter !== 'all'
                ? 'No policies match your filters. Try adjusting the search or status.'
                : 'No leave policies yet. Create your first one using the button above.'}
            </Alert>
          </Box>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            {policies.map((policy, idx) => (
              <Box key={policy._id}
                sx={{
                  px: 5, py: 4,
                  borderBottom: idx < policies.length - 1 ? t => `1px solid ${t.palette.divider}` : 'none',
                  display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
                  gap: 3, flexWrap: 'wrap',
                  '&:hover': { bgcolor: 'action.hover' },
                  transition: 'background 0.15s'
                }}
              >
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1, flexWrap: 'wrap' }}>
                    <Typography fontWeight={600} variant='body1'>{policy.name}</Typography>
                    <StatusChip status={policy.status} />
                    {policy.version != null && (
                      <Chip label={`v${policy.version}`} size='small' variant='outlined' sx={{ fontSize: '0.7rem', height: 20 }} />
                    )}
                  </Box>

                  {policy.description && (
                    <Typography variant='body2' color='text.secondary' sx={{ mb: 1, maxWidth: 600 }} noWrap>
                      {policy.description}
                    </Typography>
                  )}

                  <Typography variant='caption' color='text.secondary'>
                    Effective: {formatDate(policy.effectiveFrom)}
                    {policy.effectiveTo ? ` → ${formatDate(policy.effectiveTo)}` : ''}
                    {' · '}
                    {policy.totalLeaveTypesCount ?? policy.leaveTypes?.length ?? 0} leave type{(policy.totalLeaveTypesCount ?? policy.leaveTypes?.length) !== 1 ? 's' : ''}
                    {policy.updatedAt && ` · Updated ${formatDate(policy.updatedAt)}`}
                  </Typography>

                  {policy.leaveTypes?.length > 0 && (
                    <Box sx={{ display: 'flex', gap: 1, mt: 1.5, flexWrap: 'wrap' }}>
                      {policy.leaveTypes.map((lt, i) => (
                        <Tooltip
                          key={lt._id || lt.code || i}
                          title={`${lt.credit?.totalPerYear ?? '?'} days/yr · ${lt.isPaid ? 'Paid' : 'Unpaid'}${lt.carryForward?.allowed ? ' · CF' : ''}`}
                        >
                          <Chip
                            label={lt.code || lt.name}
                            size='small'
                            variant='outlined'
                            sx={{
                              borderColor: lt.color || '#6B7280',
                              color: lt.color || 'text.primary',
                              backgroundColor: `${lt.color || '#6B7280'}18`
                            }}
                          />
                        </Tooltip>
                      ))}
                    </Box>
                  )}

                  <Box sx={{ display: 'flex', gap: 1, mt: 1, flexWrap: 'wrap', alignItems: 'center' }}>
                    {policy.applicableFor?.employmentTypes?.length > 0
                      ? policy.applicableFor.employmentTypes.map(type => (
                        <Chip key={type} label={type} size='small' variant='tonal' color='secondary' />
                      ))
                      : <Chip label='All employees' size='small' variant='tonal' color='secondary' />
                    }
                    {policy.applicableFor?.departments?.length > 0 && (
                      <Chip
                        label={`${policy.applicableFor.departments.length} dept${policy.applicableFor.departments.length > 1 ? 's' : ''}`}
                        size='small' variant='tonal' color='info'
                        icon={<Icon icon='tabler:building' fontSize='0.75rem' />}
                      />
                    )}
                    {policy.applicableFor?.roles?.length > 0 && (
                      <Chip
                        label={`${policy.applicableFor.roles.length} role${policy.applicableFor.roles.length > 1 ? 's' : ''}`}
                        size='small' variant='tonal' color='info'
                        icon={<Icon icon='tabler:user-check' fontSize='0.75rem' />}
                      />
                    )}
                    {policy.applicableFor?.locations?.length > 0 && (
                      <Chip
                        label={policy.applicableFor.locations.join(', ')}
                        size='small' variant='tonal' color='info'
                        icon={<Icon icon='tabler:map-pin' fontSize='0.75rem' />}
                      />
                    )}
                  </Box>
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0 }}>
                  {policy.status !== 'archived' && (
                    <Tooltip title='Edit Policy'>
                      <IconButton size='small' onClick={() => handleEdit(policy)}>
                        <Icon icon='tabler:pencil' fontSize='1.1rem' />
                      </IconButton>
                    </Tooltip>
                  )}
                  <PolicyActionsMenu
                    policy={policy}
                    actionLoading={actionLoading}
                    onEdit={handleEdit}
                    onActivate={canActivate ? handleActivate : null}
                    onDeactivate={canActivate ? handleDeactivate : null}
                    onArchive={canActivate ? handleArchive : null}
                    onDelete={handleDelete}
                  />
                </Box>
              </Box>
            ))}
          </Box>
        )}

        {!loading && pagination.total > rowsPerPage && (
          <>
            <Divider />
            <TablePagination
              component='div'
              count={pagination.total}
              page={page}
              onPageChange={(_, newPage) => setPage(newPage)}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0) }}
              rowsPerPageOptions={[10, 20, 50]}
            />
          </>
        )}
      </CardContent>

      <LeavePolicyDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        editData={editData}
        onSuccess={handleSuccess}
      />

      <ConfirmDialog
        open={confirm.open}
        onClose={() => setConfirm(c => ({ ...c, open: false }))}
        onConfirm={execConfirm}
        title={confirm.title}
        message={confirm.message}
        confirmLabel={confirm.label}
        confirmColor={confirm.color}
        loading={Boolean(actionLoading)}
      />
    </Card>
  )
}

export default TabLeavePolicy
