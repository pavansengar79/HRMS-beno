// ** Next Imports
import Head from 'next/head'
import { Router } from 'next/router'

// ** Store Imports
import store from 'src/store'
import { Provider } from 'react-redux'

// ** Loader Import
import NProgress from 'nprogress'

// ** Emotion Imports
import { CacheProvider } from '@emotion/react'

// ** Config Imports
import 'src/configs/i18n'
import { defaultACLObj } from 'src/configs/acl'
import themeConfig from 'src/configs/themeConfig'

// ** Fake-DB Import
import 'src/@fake-db'

// ** Third Party Import
import { Toaster } from 'react-hot-toast'

// ** Component Imports
import UserLayout from 'src/layouts/UserLayout'
import AclGuard from 'src/@core/components/auth/AclGuard'
import ThemeComponent from 'src/@core/theme/ThemeComponent'
import AuthGuard from 'src/@core/components/auth/AuthGuard'
import GuestGuard from 'src/@core/components/auth/GuestGuard'

// ** Spinner Import
import Spinner from 'src/@core/components/spinner'

// ** Contexts
import { AuthProvider } from 'src/context/AuthContext'
import { SettingsConsumer, SettingsProvider } from 'src/@core/context/settingsContext'

// ** ACL
import { AbilityContext } from 'src/layouts/components/acl/Can'
import { buildAbilityFor } from 'src/configs/acl'

// ** Hooks
import { useAuth } from 'src/hooks/useAuth'
import { useEffect } from 'react'
import { useDispatch } from 'react-redux'

// ** Hierarchy store — rehydrate selection from localStorage
import { initFromStorage } from 'src/store/hierarchy/hierarchySlice'

// ** Hierarchy sync — updates selected context when URL query params change
import HierarchySidebarSync from 'src/layouts/components/HierarchySidebarSync'

// ** Styled Components
import ReactHotToast from 'src/@core/styles/libs/react-hot-toast'

// ** Utils Imports
import { createEmotionCache } from 'src/@core/utils/create-emotion-cache'

// ** Prismjs Styles
import 'prismjs'
import 'prismjs/themes/prism-tomorrow.css'
import 'prismjs/components/prism-jsx'
import 'prismjs/components/prism-tsx'

// ** React Perfect Scrollbar Style
import 'react-perfect-scrollbar/dist/css/styles.css'
import 'src/iconify-bundle/icons-bundle-react'

// ** Global css styles
import '../../styles/globals.css'

const clientSideEmotionCache = createEmotionCache()

// ** Pace Loader
if (themeConfig.routingLoader) {
  Router.events.on('routeChangeStart', () => {
    NProgress.start()
  })
  Router.events.on('routeChangeError', () => {
    NProgress.done()
  })
  Router.events.on('routeChangeComplete', () => {
    NProgress.done()
  })
}

const Guard = ({ children, authGuard, guestGuard }) => {
  if (guestGuard) {
    return <GuestGuard fallback={<Spinner />}>{children}</GuestGuard>
  } else {
    return <AuthGuard fallback={<Spinner />}>{children}</AuthGuard>
  }
}

// ** Configure JSS & ClassName
const App = props => {
  const { Component, emotionCache = clientSideEmotionCache, pageProps } = props

  // Variables
  const contentHeightFixed = Component.contentHeightFixed ?? false

  const getLayout =
    Component.getLayout ?? (page => <UserLayout contentHeightFixed={contentHeightFixed}>{page}</UserLayout>)
  const setConfig = Component.setConfig ?? undefined
  // Protect all pages by default; set `Component.guestGuard = true` for public pages like login/register.
  // If you need a public page, explicitly set `Component.authGuard = false`.
  const authGuard = Component.authGuard ?? true
  const guestGuard = Component.guestGuard ?? false
  const aclAbilities = Component.acl ?? defaultACLObj

  return (
    <Provider store={store}>
      <CacheProvider value={emotionCache}>
        <Head>
          <title>{`${themeConfig.templateName}`}</title>
          <meta
            name='description'
            content={`${themeConfig.templateName} – Material Design React Admin Dashboard Template – is the most developer friendly & highly customizable Admin Dashboard Template based on MUI v5.`}
          />
          <meta name='keywords' content='Material Design, MUI, Admin Template, React Admin Template' />
          <meta name='viewport' content='initial-scale=1, width=device-width' />
        </Head>

        <AuthProvider>
          <AppContent 
            Component={Component} 
            pageProps={pageProps} 
            getLayout={getLayout} 
            setConfig={setConfig} 
            authGuard={authGuard} 
            guestGuard={guestGuard} 
            aclAbilities={aclAbilities} 
          />
        </AuthProvider>
      </CacheProvider>
    </Provider>
  )
}

const AppContent = ({ Component, pageProps, getLayout, setConfig, authGuard, guestGuard, aclAbilities }) => {
  const auth = useAuth()
  const ability = auth.user ? buildAbilityFor(auth.user.role, aclAbilities.subject) : null

  // Rehydrate selected company/unit from localStorage on app start
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(initFromStorage())
  }, [dispatch])

  return (
    <SettingsProvider {...(setConfig ? { pageSettings: setConfig() } : {})}>
      <SettingsConsumer>
        {({ settings }) => {
          return (
            <ThemeComponent settings={settings}>
              <AbilityContext.Provider value={ability}>
                <Guard authGuard={authGuard} guestGuard={guestGuard}>
                  <HierarchySidebarSync />
                  {/* Bypassed AclGuard for now */}
                  {/* <AclGuard aclAbilities={aclAbilities} guestGuard={guestGuard} authGuard={authGuard}> */}
                    {getLayout(<Component {...pageProps} />)}
                  {/* </AclGuard> */}
                </Guard>
              </AbilityContext.Provider>
              <ReactHotToast>
                <Toaster position={settings.toastPosition} toastOptions={{ className: 'react-hot-toast' }} />
              </ReactHotToast>
            </ThemeComponent>
          )
        }}
      </SettingsConsumer>
    </SettingsProvider>
  )
}

export default App
